""" Utilities to print directory trees

Notes
-----
Based on 
    `<https://github.com/kddnewton/tree/blob/main/tree.py>_`
         
"""
from __future__ import annotations

import pathlib
import dataclasses as dc

from .._sys import walk
from .._typing import (
        Iterable,
        Callable,
        )

__all__ = [
        'dirtree',
        ]

@dc.dataclass
class DirTreeCfg:
    """ Directory tree configuration
    """
    branch_sep: str = '|   '
    branch_end: str = '|__ '
    dir_end: str = '/'
    dirs_first: bool = True

class Branch:
    """ A tree branch
    """

    def __init__(
            self,
            pth: pathlib.Path,
            root: pathlib.Path,
            dt_cfg: DirTreeCfg,
            ):
        self.pth = pth
        self.root = root
        self.dt_cfg = dt_cfg

        # relative path
        self.rpth = self.pth.relative_to(self.root)

        self.is_dir = pth.is_dir()
        self.name = pth.name


    def to_str(self):
        """ String representation of the branch
        """
        name = self.name
        if self.is_dir:
            name = f"{name}{self.dt_cfg.dir_end}"
        parts = len(self.rpth.parts)

        if parts == 0:
            return name
        else:
            branch_levels = parts - 1
            branch = self.dt_cfg.branch_sep*branch_levels + self.dt_cfg.branch_end
            return branch + name


class DirTree:
    """ Directory tree

    Parameters
    ----------
    root: path-like
        Root folder

    paths: iterable
        An iterable containing pathlib.Path instances

    dirs_first: bool, default True
        If True, directories are printed first.


    """

    def __init__(
            self,
            root: str | pathlib.Path,
            paths: Iterable,
            file_arrows: dict | None = None,
            dir_arrows: dict | None = None,
            **kargs,
            ):
        self.root = root
        self.paths = paths
        self.dt_cfg = DirTreeCfg(**kargs)


        self.dir_arrows = dir_arrows if isinstance(dir_arrows, dict) else {}
        self.file_arrows = file_arrows if isinstance(file_arrows, dict) else {}
                

    def mk_branches(self) -> list[Branch]:
        """ List with branches
        """
        kargs = {
                'root': self.root,
                'dt_cfg': self.dt_cfg,
                }
        root_branch = Branch(pth=self.root, **kargs)
        out = []
        if self.dt_cfg.dirs_first is True:
            paths = self.mk_paths_dirs_first()
        else:
            paths = self.paths
        for pth in paths:
            branch = Branch(pth=pth, **kargs)
            out.append(branch)
        return out

    def to_str(self):
        """
        """
        out = []

        for b in self.mk_branches():

            if b.is_dir is True and b.name in self.dir_arrows:
                arrow = self.dir_arrows[b.name]
            elif b.name in self.file_arrows:
                arrow = self.file_arrows[b.name]
            else:
                arrow = None

            out.append((b.to_str(), arrow))

        # Get max length of str
        max_indent = max(len(x[0]) for x in out) + 2

        lines = []
        for branch, arrow in out:
            if arrow is not None:
                indent = ' '*(max_indent - len(branch))
                branch = f"{branch}{indent}<- {arrow}"
            lines.append(branch)


        return '\n'.join(lines)


    def mk_paths_dirs_first(self):
        """ Sort self.paths so directories come first
        """
        out = []
        for pth in self.paths:
            rpth = pth.relative_to(self.root)
            parts = rpth.parts
            parts = [f'A_{x}' for x in parts]
            if pth.is_file():
                parts[-1] = f'Z_{parts[-1]}'
            order = '/'.join(parts)
            tup = (order, pth)
            out.append(tup)
        return [x[-1] for x in sorted(out)]

# TODO: Finish docstring
def dirtree(
        root: str|pathlib.Path,
        paths: Iterable|None = None,
        exclude: set[str] | None = None,
        include: set[str] | None = None,
        dirs_only: bool = False,
        files_only: bool = False,
        filter_files: Callable | None = None,
        filter_dirs: Callable | None = None,
        file_arrows: dict | None = None,
        dir_arrows: dict | None = None,
        indent: str = '',
        recursive: bool = True,
        **kargs,
        ):
    """ Returns a string with a directory tree representation of `paths`

    Parameters
    ----------
    file_arrows: dict, optional
        If given, must be a dictionary mapping a file name or sub-path to an arrow message

    dir_arrows: dict, optional
        If given, must be a dictionary mapping a dir name or sub-path to an arrow message

    """
    # If paths is None, walk the root folder
    if paths is None:
        paths = walk(
                root=root,
                exclude=exclude,
                include=include,
                dirs_only=dirs_only,
                files_only=files_only,
                filter_dirs=filter_dirs,
                filter_files=filter_files,
                recursive=recursive,
                )
    c = DirTree(
            root=root, 
            paths=paths, 
            file_arrows=file_arrows,
            dir_arrows=dir_arrows,
            **kargs)
    tree = c.to_str()

    if len(indent) > 0:
        tree = '\n'.join(f"{indent}{x}" for x in tree.splitlines())
    return tree










