""" Setup/check utils

"""
# TODO: Finish docstrings
from __future__ import annotations

import pathlib
import textwrap
import sys

from .. import (
        opts,
        _pp,
        _sys,
        defaults,
        )

__all__ = [
        'setup',
        ]

DEFAULTS = defaults.DEFAULTS
cfg = opts.cfg


def _dedent(text):
    return textwrap.dedent(text)

# TODO: Replace all _pp.fmt_msg
def _fmt_hdr(
        msg: str, 
        skip_before: int = 0,
        skip_after: int = 0,
        ):
    """
    """
    return '\n'*skip_before + _pp.fmt_msg(msg, as_hdr=True) + '\n'*skip_after

class Setup:
    """
    """


    def __init__(
            self,
            ):

        self.branches = cfg.locs.branches

        # will be updated after each ask_yes
        self._proceed = True
        self._exit = "Setup stopped, goodbye!"

        self.prj_folder_name = cfg.locs.tk_prjdir.name



    # DEPRECATED?
    def _mk_prj_tree(self, branches):
        """
        """

        paths = []
        arrows = {}

        for name in branches:
            info = getattr(cfg.branches, name)
            pth = info.pth
            paths.append(pth)
            if info.arrow is not None:
                arrows[pth.name] = info.arrow

        dir_filter = lambda x: not (
            x.name in cfg.locs.sys_dirs or x.name.startswith('.'))
                
        prj_tree = _pp.dirtree(
                paths=paths,
                root=cfg.branches.prj_root.pth,
                filter_dirs=dir_filter,
                recursive=False,
                file_arrows=arrows,
                dir_arrows=arrows,
                )
        return prj_tree

    def _ask_yes(
            self, 
            msg: str | None = None,
            add_line_sep: bool = True,
            ):
        """
        """
        if add_line_sep is True:
            print('')
        self._proceed = _pp.ask_yes(msg, strict=False, default_yes=True)

        if self._proceed is True and add_line_sep is True:
            print('')
        else:
            print(self._exit)

        return self._proceed

    def _print_msg(self, msg: list):
        """
        """
        out = '\n'.join(msg)
        print(out)

    def intro(self) -> bool:
        """ Introduces the `tk_utils`

        """
        #prj_tree = self._mk_prj_tree(self.branches)

        self._print_msg([
        _fmt_hdr("Welcome to the `tk_utils` module!", skip_before=0),
        _dedent('''
        This setup utility will perform the following actions:

        1. Check if your Python version is supported.

        2. Introduce the tk_utils.backup() function:

           This will create a new folder inside PyCharm and perform an initial
           backup of all your project files

        3. Introduce the tk_utils.sync_dbox() function:

           This will download all files from Dropbox into a new folder in
           PyCharm

           You will also be given the option to copy all NEW files downloaded
           from Dropbox into their proper locations. 
        '''),
        #prj_tree,
        #_dedent('''
        #NOTE: Your actual folder may include additional files! 
        #'''),
        ])
        self._ask_yes()

    def chk_py_version(self):
        """
        """
        ver = sys.version_info[1]
        min_ver = DEFAULTS['sys']['req_version_minor']

        print(_fmt_hdr(
            "Checking if your version of Python is supported...",
            skip_before=1,
            skip_after=1,
            ))

        if ver < min_ver:
            self._print_msg([
            _pp.fmt_msg(f"WARNING: Your computer is running Python 3.{ver}", as_hdr=True),
            _dedent(f'''
            This module was tested for versions 3.{min_ver}+. It may or may not work
            for earlier versions. You should install version 3.{min_ver}+.

            Type NO to exit this setup utility.
            '''),
            ])
        else:
            print(f"Your Python version 3.{ver} is supported!")
        self._ask_yes()


    def backup(self):
        """ Introduces the backup utility
        """
        branches = [
            'prj_root',
            'backup',
            ]
        prj_tree = self._mk_prj_tree(branches)

        self._print_msg([
        _fmt_hdr("The tk_utils.backup() function", skip_before=1, skip_after=1),
        _dedent(f'''\
        This function will copy all your project files into a new "dated" folder 
        under "_backup":
        
            {cfg.locs.tk_prjdir.name}/                            <- PyCharm project folder
            |__ _backup/                        <- Backup folder (NEW)
            |   |__ <YYYY_MM_DD_HH_MM_SS>       <- Dated folder (NEW)
            |   |   ... your files here ...

        This setup utility will call the tk_utils.backup() function now.'''),
        ])

        if not self._ask_yes("Backup files? "):
            return
        tko = _sys.TKOrganizer()

        #print("Backing up your files now...")
        tko.backup()

        #print('Done!')
        if not self._ask_yes():
            return

        dir_arrows = {
                tko.tk_root.name: "Your PyCharm project folder",
                tko.bk_root.name: "Backup folder",
                tko.bkdir.name: "Open this folder",
                }
        bk_filter = lambda x: tko.bk_root.name in (x.name, x.parent.name)
        bk_tree = _pp.dirtree(
                root=tko.tk_root,
                filter_dirs=bk_filter,
                dirs_only=True,
                dir_arrows=dir_arrows,
                )

        self._print_msg([
        _pp.fmt_msg("The _backup folder", as_hdr=True),
        _dedent(f'''
        A new folder was created inside your PyCharm project folder:

            {tko.tk_root.name}/          <- PyCharm project folder
            |   ...
            |__ _backup/                        <- Backup folder
            |   |__ {tko.bkdir.name}/      <- New dated folder

        Open the '{tko.bkdir.name}' folder to see your backup files.
        '''),
        bk_tree,
        _dedent(
        f'''
        NOTE: If you do not see the '_backup/{tko.bkdir.name}' folder, right click
        on the `{tko.tk_root.name}` project folder and choose 
        "Reload from disk...".'''),
        ])

        if not self._ask_yes():
            return

        self._print_msg([
        _pp.fmt_msg("Calling the tk_utils.backup() function", as_hdr=True),
        _dedent('''
        You can backup your files at anytime: Simply open the Python Console
        and type:

            >>> import tk_utils
            >>> tk_utils.backup()

        We will now discuss the tk_utils.sync_dbox() function.
        '''),
        ])
        self._ask_yes()
        

    def sync(self):
        """ Introduces the syncing utility
        """
        branches = [
            'prj_root',
            'dropbox',
            ]
        prj_tree = self._mk_prj_tree(branches)

        tko = _sys.TKOrganizer()

        self._print_msg([
        _pp.fmt_msg("The tk_utils.sync_dbox() function", as_hdr=True),
        _dedent(f'''
        This function will create a mirror of the Dropbox shared folder inside
        your PyCharm project folder.

        To prevent conflicts, all Dropbox files will be saved under a
        dedicated folder called '_dropbox':

            {tko.tk_root.name}/             <- PyCharm project folder
            |   ...
            |__ _dropbox/            <- Dropbox mirror

        Every time you call the `tk_utils.sync_dbox()`, the files under
        `_dropbox` will be REPLACE with the current content of the Dropbox
        shared folder.'''),
        ])
        if not self._ask_yes():
            return

        self._print_msg([
        _dedent(f'''
        IMPORTANT: The entire `_dropbox` folder will be ERASED every time you
        sync. 

        NOTE: Before syncing, the `tk_utils.sync_dbox()` function will
        automatically backup all your files.

        This setup utility will now call this function for you.'''),
        ])

        if not self._ask_yes("Start sync? "):
            return

        tko.backup(quiet=True)
        tko.sync_dbox(quiet=False)

        dir_arrows = {
                tko.tk_root.name: "Your PyCharm project folder",
                tko.dbox_root.name: "Mirror of the Dropbox shared folder",
                }

        dbox_filter = lambda x: tko.dbox_root.name in (x.name, x.parent.name)

        dbox_tree = _pp.dirtree(
                root=tko.tk_root,
                filter_dirs=dbox_filter,
                dirs_only=True,
                dir_arrows=dir_arrows,
                )

        self._print_msg([
        _dedent('''
        All the files from Dropbox are now available here:
        '''),
        dbox_tree,
        _dedent('''
        Open the `_dropbox` folder now to see the downloaded files

        NOTE: If you do not see the _dropbox folder, right click on the
        `toolkit` project folder and choose "Reload from disk...".

        '''),
        ])

        if not self._ask_yes():
            return

        self._print_msg([
        _pp.fmt_msg("Automatic backup before syncing", as_hdr=True),
        _dedent(f'''
        Every time you sync, a new backup folder will be created. Open the
        following folder to see you backup files:

            {tko.tk_root.name}/                 <- PyCharm project folder
            |   ...
            |__ _backup/                      <- Backup folder
            |   | ...
            |   |__ {tko.bkdir.name}/      <- New dated folder
        '''),
        ])
        if not self._ask_yes():
            return

        self._print_msg([
        _pp.fmt_msg("Automatically copying new files", as_hdr=True),
        _dedent('''
        After syncing, the `tk_utils.sync_dbox()` function will check if there
        are any files in the `_dropbox` folder which are NOT present in your
        PyCharm project folder.

        You will be given the option to have those files automatically copied
        from the `_dropbox` into your project folder.

        IMPORTANT: Only NEW files, i.e., files not present in your project
        folder, will be copied. No existing file will be overwritten.

        We will check for new files now.'''),
        ])

        if not self._ask_yes():
            return

        tko.copy_new_files(quiet=False)

        if not self._ask_yes():
            return

        #dbox_filter = lambda x: cfg.locs.dbox_dir in (
        #        x, x.parent, x.parents[1])
        #dbox_tree = _pp.dirtree(
        #        root=cfg.locs.tk_prjdir,
        #        filter_dirs=dbox_filter,
        #        dirs_only=True,
        #        dir_arrows=dir_arrows,
        #        )

        #self._print_msg([
        #_pp.fmt_msg("The _dropbox folder", as_hdr=True),
        #_dedent('''
        #The `tk_utils.sync_dbox()` function allows you to keep a mirror of the
        #Dropbox Shared folder inside PyCharm.

        #Whenever we upload a new file to Dropbox, you can use the
        #`tk_utils.sync_dbox()` function to automatically add it to the
        #_dropbox folder.

        #After that, you can "Drag and Drop" the new files from _dropbox into
        #their proper location.

        #Next, we will discuss an example.

        #'''),
        #])

        #self._ask_yes()

        #self._print_msg([
        #_pp.fmt_msg("Drag and drop the ff_daily.csv file", as_hdr=True),
        #_dedent('''
        #At this stage you should have a folder called "data" inside your
        #PyCharm project folder. You will also notice that the _dropbox folder
        #also includes a "data" folder. This folder includes the most recent
        #files uploaded to Dropbox. Inside `_dropbox/data`, you will find a
        #file called `ff_daily.csv`. This file will be important later in the
        #course. 

        #toolkit/
        #|__ _dropbox/
        #|   |__ data/               <- Most recent files
        #|   |   |__ ff_daily.csv    <- We will use this file later in the course
        #|__ data/                   <- Your 'data' folder


        #Drag and drop the `ff_daily.csv` file from _dropbox/data into
        #toolkit/data, as illustrated below:

        #toolkit/
        #|__ _dropbox/
        #|   |__ data/               
        #|   |   |__ ff_daily.csv    <- Drag from here...
        #|__ data/                   <- ... into this folder

        #PyCharm will open a "Move" window. Press "Refactor" to move the file.

        #IMPORTANT: PyCharm will issue a warning if the destination file
        #already exists. If that happens, press "Cancel".


        #The end result should look like this:

        #toolkit/                            
        #|__ _dropbox/
        #|   |__ data/               
        #|                                   <- Moved from here
        #|__ data/                           
        #|   |___ ff_daily.csv               <- ... into here

        #HINT: If you accidentally replace a file, look for it under the most
        #recent _backup folder. Remember that the .sync_dbox() function
        #automatically calls the .backup() function before syncing.

        #This concludes the sync_dbox tutorial.
        #'''),
        #])
        #self._ask_yes()

        #,
        #"",
        #"To invoke this syncing utility in the future, open the Python Console and type:",
        #"",
        #"  >>> import tk_utils",
        #"  >>> tk_utils.sync_dbox()",
        #"",
        #"HINT: You can drag and drop any file from the _dropbox folder into the PyCharm project folder.",
        #"",
        #'This means you do not have to manually download any files from',
        #"the Dropbox shared folder. All you need to do is to use this syncing utility",
        #"",
        #"IMPORTANT: Do not manually save any file into the _dropbox folder!",
        #"All files inside _dropbox will be erased!",
        #"",
        #"NOTE: The syncing utility will automatically backup your files!",
        #"There is not need to backup prior to syncing.",
        #
        #"",
        #]
        #print('\n'.join(msg))


    def cleanup(self):
        """ Erase the installer
        """
        installer_pth = cfg.branches.installer.actual_pth
        if installer_pth.exists():
            installer_pth.unlink()
        self._print_msg([
        _pp.fmt_msg("Cleaning up and hints", as_hdr=True),
        _dedent('''
        This concludes the setup. Note that the installer is no longer
        required and will be deleted (but it can be found under _backup)

        Please keep the following in mind:

        - Please do not modify the tk_utils package
            - In particular, do NOT unzip the _tk_utils.zip file. 

        - The `tk_utils` package will be automatically updated every time you
          call `tk_utils.sync_dbox()`

          - There is no need to update it yourself.

        - We will discuss other `tk_utils` functions later in the course.

        IMPORTANT: You do NOT need to call the tk_utils.setup() again. 

        All done!

        ''')
        ])



    def setup(self):
        """
        """
        if self._proceed: 
            self.intro()
        if self._proceed: 
            self.chk_py_version()
        #if self._proceed: 
        #    self.mk_folders()
        if self._proceed: 
            self.backup()
        if self._proceed: 
            self.sync()
        if self._proceed: 
            self.cleanup()



def setup():
    """ Setup utility for the tk_utils package. Will perform the following
    operations:

    - Introduce `tk_utils`

    """

    c = Setup()
    c.setup()







