""" Parameter descriptions

         
"""
from __future__ import annotations

from .. import (
        defaults,
        decorators,
        )


PARMS_WALK = {
    'root': """
    root: pathlib.Path
        The root folder
    """,
    'exclude': """
    exclude: set, optional
        Path names to exclude.
    """,
    'include': """
    include: set, optional
        Path name to include
    """,
    'filter_files': """
    filter_files: Callable
        A callable that takes a Path and returns True if a file should be
        included and False otherwise
    """,
    'filter_dirs': """
    filter_dirs: callable
        A callable that takes a Path and returns True if a folder should be
        included and False otherwise.
        If a folder is excluded, all its children are excluded
    """,
    'dirs_only': """
    dirs_only: bool, default False
        If True, only directories will be returned
    """,
    'files_only': """
    files_only: bool, default False
        If True, only files will be returned
    """,
    'recursive': """
    recursive: bool, default True
        If True, walk directories recursively
    """,
    }
PARMS_COPYTREE = PARMS_WALK | {
    'src': """
    src: path-like
        Location of the source file/folder.

        If `src` is a folder, `dst` must be a folder. In this case, `src` is
        copied into `dst`.  Parent folders will be created.

        If `src` is a file, `dst` must also represent a file. In this case,
        copies `src` to `dst` if `dst` does not exist. Parent folders will be
        created.
    """,
    'dst': """
    dst: path-like
        Location of the destination file/folder. 

        If `src` is a folder, `dst` must be a folder. In this case, `src` is
        copied into `dst`.  Parent folders will be created.

        If `src` is a file, `dst` must also represent a file. In this case,
        copies `src` to `dst` if `dst` does not exist. Parent folders will be
        created.
    """,
    'dry_run': """
    dry_run: bool, default False
        If True, do not copy any files/folders but display a directory tree
        with the files to be copied or skipped.
    """,
    }

PARMS = {
        'walk': PARMS_WALK,
        'copytree': PARMS_COPYTREE,
        }




