""" Defaults

         
"""
from __future__ import annotations

import copy as _copy

DROPBOX_URL = 'https://www.dropbox.com/scl/fo/it791t4gsvb275sgkc44m/AHvysANbaep2ZoQl7-Gf4-4?rlkey=t29q4rr4epsjz3538gy3yr49h&st=7j1lokjc&dl=1'

DOCTEST_DEFAULTS = {
        'print_docstring': False,
        'print_examples': True,
        'print_hdr': True,
        'print_mod': True,
        'verbose': False, 
        'compileflags': None, 
        }

PP_DEFAULTS = {
    'color': None,
    'indent': '',
    'pretty': True,
    'width': 60,
    'sort_dicts': False,
    'compact': False,
    'depth': None,
    'as_hdr': False,
    'underscore_numbers': True,
    'show_type': False,
    'df_info': False,
    'df_max_cols': None,
    'df_max_rows': None,
    'min_sep_width': 40,
    'max_sep_width': None,
    }

LOCS_DEFAULTS = {
        'dropbox_url': DROPBOX_URL,
        'dbox_dirname': '_dropbox',
        'pkg_name': 'tk_utils',
        'prj_dirname': 'toolkit',
        'data_dirname': 'data',
        'lec_dirname': 'lectures',
        'in_class_dirname': 'in_class',
        'bk_dirname': '_backup',
        'tk_cfg_modname': 'toolkit_config',
        'tk_zip_name': '_tk_utils.zip',
        'installer_modname': 'tk_installer.py',
        'sys_dirs': {
            '.idea',
            '__pycache__',
            'venv',
            },
        'branches': [
            'prj_root',
            'backup',
            'dropbox',
            'data',
            'in_class',
            'lectures',
            'tk_utils',
            'tk_cfg',
            ],
        }
LOCS_DEFAULTS['tk_cfg_filename'] = LOCS_DEFAULTS['tk_cfg_modname'] + '.py'
LOCS_DEFAULTS['ignore_dirs'] = {
    '.idea',
    '__pycache__',
    LOCS_DEFAULTS['dbox_dirname'],
    LOCS_DEFAULTS['bk_dirname'],
    }

SYS_DEFAULTS = {
        'req_version_minor': 11,
        }

DEFAULTS = {
        'doctest': DOCTEST_DEFAULTS,
        'pp': PP_DEFAULTS,
        'locs': LOCS_DEFAULTS,
        'sys': SYS_DEFAULTS,
        }


## NOTE: See individual configuration files
## e.g., _stata.defaults will have a different config
#PP_DEFAULTS = {
#    'hdr_color': 'green',
#    'pth_color': 'yellow',
#    'tab_color': 'yellow',
#    'debug_color': 'yellow',
#    'quote_tab': True,
#    'quote_pth': True,
#    'indent': '',
#    'debug': False,
#    'width': 60,
#    'quiet': False,
#    }
#
#COMPRESSION = {
#        'compress': False,
#        'compress_format': 'zstd',
#        'compress_ext': 'zst',
#        }
#
#if COMPRESSION['compress_format'] == 'zstd':
#    COMPRESSION['compress_level'] = 6
#else:
#    COMPRESSION['compress_level'] = None
#
#
#
#
