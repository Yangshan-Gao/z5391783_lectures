""" Decorators


"""
from __future__ import annotations

import asyncio
import functools
import textwrap

from ._typing import (
        Callable,
        Any,
        TypeVar,
        FuncType,
        Union,
        )

__all__ = [
        'with_vars',
        'doc',
        'lazy_property',
        'cached_property',
        ]

# used in decorators to preserve the signature of the function it decorates
# see https://mypy.readthedocs.io/en/stable/generics.html#declaring-decorators
F = TypeVar("F", bound=FuncType)



def with_vars(a):
    """ Decorator to inject variables into the decorated function scope

    Parameters
    ----------
    vars : dict
        A dictionary with the variables/values to be added to the function

    Usage
    -----
    vars_ = {'a': 1, 'b': 2}
    @with_vars(vars_)
    def some_func(parm=None):
        print(a)
        print(b)
        b = 'new value'


    Notes
    -----
    - Adapted from `this thread <https://stackoverflow.com/questions/17862185/how-to-inject-variable-into-scope-with-a-decorator>`_

    """
    def add_to_scope(func):
        """ Decorator. """
        @functools.wraps(func)
        def inner(*args, **kwargs):
            fglobals = func.__globals__
            # Save copy of any global values that will be replaced.
            org_ns = {key: fglobals[key] for key in vars if key in fglobals}
            fglobals.update(vars)
            try:
                result = func(*args, **kwargs)
            finally:
                fglobals.update(org_ns)  # Restore replaced globals.
            return result
        return inner
    return add_to_scope

def _indent(text: str|None, level: int = 1) -> str:
    """ Aux function to indent docstring parameters

    Notes
    -----
    - Adapted from `indent <https://github.com/pandas-dev/pandas/blob/main/pandas/util/_decorators.py>`_
    """
    if not text or not isinstance(text, str):
        return ""
    # First dedent then indent
    if text.startswith('\n'):
        text = textwrap.dedent(text[1:])

    pfix = ' '*3
    if level >= 1:
        pfix = pfix + ' '*4*(level-1)


    text = textwrap.indent(text, pfix)
    # Remove the indentation from the first line
    n = len(pfix)
    return text[n:]

def fmt_doc_parm(
        text: str,
        strip: bool = False,
        indent: str = '',
        ):
    """ Formats an entry meant to be the key of a dictionary passed to the
    `doc` decorator
    """
    if strip:
        text = text.strip()
    if len(indent) > 0:
        text = '\n'.join(f"{indent}{x}" for x in text.splitlines())
    return text

def doc(
        *docstrings: str|Callable, 
        parms: dict,
        indent: int = 1, 
        ) -> Callable[[F], F]:
    """ Recursively input parameter descriptions into docstrings.

    Parameters
    ----------
    *docstrings : str or callable
        The string / docstring / docstring template to be appended in order
        after default docstring under callable.

    parms  dict
        key-value pairs which will be used to format the docstring

    indent : int, optional
        The indentation level (1 = four spaces)

    Notes
    -----
    - Based on `doc decorator <https://github.com/pandas-dev/pandas/blob/main/pandas/util/_decorators.py>`_

    """
    params = {k:_indent(v, indent) for k, v in parms.items()}

    def decorator(decorated: F) -> F:
        # collecting docstring and docstring templates
        docstring_components: list[str | tp.Callable] = []
        if decorated.__doc__:
            docstring_components.append(textwrap.dedent(decorated.__doc__))

        for docstring in docstrings:
            if hasattr(docstring, "_docstring_components"):
                # error: Item "str" of "Union[str, Callable[..., Any]]" has no attribute
                # "_docstring_components"
                # error: Item "function" of "Union[str, Callable[..., Any]]" has no
                # attribute "_docstring_components"
                docstring_components.extend(
                    docstring._docstring_components  # type: ignore[union-attr]
                )
            elif isinstance(docstring, str) or docstring.__doc__:
                docstring_components.append(docstring)

        # Remove indentation of the anchors

        # formatting templates and concatenating docstring
        decorated.__doc__ = "".join(
            [
                component.format(**params)
                if isinstance(component, str)
                else textwrap.dedent(component.__doc__ or "")
                for component in docstring_components
            ]
        )

        # error: "F" has no attribute "_docstring_components"
        decorated._docstring_components = (  # type: ignore[attr-defined]
            docstring_components
        )
        return decorated

    return decorator

class lazy_property(property):
    """ A property decorator for lazy properties.

    Examples
    --------

    The following provide similar functionality:

    @lazy_property
    def some_property(self):
        value = foo()
        return value
    

    @property
    def some_property(self):
        if not hasattr(self, '_some_property'):
            self._some_property = foo()
        return self._some_property
    @some_property.setter
    def some_property(self, value):
        self._some_property = value

    Notes
    -----
    - Adapted from `lazy_property <https://github.com/jackmaney/lazy-property>`_

    """

    def __init__(self, method, fget=None, fset=None, fdel=None, doc=None):
        """
        """
        self.method = method
        self.cache_name = "_{}".format(self.method.__name__)
        doc = doc or method.__doc__
        super().__init__(fget=fget, fset=fset, fdel=fdel, doc=doc)
        functools.update_wrapper(self, method)

    def __get__(self, instance, owner):
        """
        """
        if instance is None:
            return self
        if hasattr(instance, self.cache_name):
            result = getattr(instance, self.cache_name)
        else:
            if self.fget is not None:
                result = self.fget(instance)
            else:
                result = self.method(instance)
            setattr(instance, self.cache_name, result)
        return result

    def __set__(self, instance, value):
        """
        """
        if instance is None:
            raise AttributeError
        if self.fset is None:
            setattr(instance, self.cache_name, value)
        else:
            self.fset(instance, value)


class cached_property(object):
    """ Decorates a property so it is only computed once per instance and then replaces
    itself with an ordinary attribute. Deleting the attribute resets the
    property.

    Notes
    -----
    - Adapted from: `cached_property <https://github.com/bottlepy/bottle/commit/fa7733e075da0d790d809aa3d2f53071897e6f76>`_
    """

    def __init__(self, func):
        self.__doc__ = getattr(func, "__doc__")
        self.func = func

    def __get__(self, obj, cls):
        if obj is None:
            return self
        if asyncio and asyncio.iscoroutinefunction(self.func):
            return self._wrap_in_coroutine(obj)
        value = obj.__dict__[self.func.__name__] = self.func(obj)
        return value

    def _wrap_in_coroutine(self, obj):
        @functools.wraps(obj)
        @asyncio.coroutine
        def wrapper():
            future = asyncio.ensure_future(self.func(obj))
            obj.__dict__[self.func.__name__] = future
            return future
        return wrapper()




