""" Docstring utils

         
"""
from __future__ import annotations

import inspect

from ._pp import colorize


def pretty_sig(func, sig):
    """
    """
    indent = ' '*len(func.__name__)
    out = str(sig)
    if len(out) > 60:
        out = f',\n{indent}'.join(out.split(','))
    return out


def func_doc(func, name_only: bool = False):
    """ Returns the documentation of a function
    """
    sig = inspect.signature(func, eval_str=True)
    sig_str = pretty_sig(func, sig)
    #fname = f"\033[4m{func.__name__}{sig}\033[0m"
    fname = colorize(f"{func.__name__}{sig_str}", 'green')
    if name_only is True:
        return fname
    else:
        docstring = func.__doc__.strip()
        return f"""{fname}: 
        
    {docstring}
    """

def mk_tk_utils_doc(
        funcs: list,
        ):
    """
    """
    _func_desc = '\n'.join([func_doc(x) for x in funcs])
    _func_list = '\n\n'.join([f"{func_doc(x, name_only=True)}" for x in funcs])
    _func_header = colorize("Functions", 'green')

    return f""" The `tk_utils` package. 

IMPORTANT: This zip file should be placed directly under the `toolkit` folder:

    toolkit/   
    | ...
    |__ tk_utils.zip            <- This file
    |__ toolkit_config.py       <- Your config file (REQUIRED)

IMPORTANT: This module is should not be modified. Also, it includes Python
concepts/libraries we did not (and will not) discuss in this course. Please
use this module "as is" and do not worry about the implementation.

IMPORTANT: This module requires a correctly configured `toolkit_config.py`
module.  If you followed the instructions in Lecture 4.4, you are all set!

This module implements the following functions:

{_func_list}

Each function is documented below:

{_func_header}
---------

{_func_desc}


"""

